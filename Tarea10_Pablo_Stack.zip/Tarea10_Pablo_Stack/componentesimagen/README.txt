Para compilar: 

g++ componentes2.cpp
./a.out CC1.pgm prueba1.pgm

-----------------------------------------------------
CC1.png es la imagen que vamos a abrir, se puede cambiar por cualquiera de las 5 que hay en la carpeta. 

prueba1.pgm es el nombre con el que se va a guardar la imagen de salida
