Para compilar: 
g++ clasificador.cpp
./a.out spamaclasificar.txt 

-------------------------------------------
spamaclasificar.txt puede ser cambiado por correoaclasificar.txt 

Las probabilidades son muy pequeñas y puede ser el caso de que en algún momento se hagan 0, esto se arregla sacando logaritmo de la multiplicación. 
